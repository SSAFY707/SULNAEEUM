-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: sulnaeeum
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user_preference`
--

DROP TABLE IF EXISTS `user_preference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_preference` (
  `preference_id` bigint NOT NULL AUTO_INCREMENT,
  `dish` varchar(10) NOT NULL,
  `level` int NOT NULL,
  `taste_body` int NOT NULL,
  `taste_flavor` int NOT NULL,
  `taste_refresh` int NOT NULL,
  `taste_sour` int NOT NULL,
  `taste_sweet` int NOT NULL,
  `taste_throat` int NOT NULL,
  `user_id` bigint DEFAULT NULL,
  `weight` varchar(20) NOT NULL,
  PRIMARY KEY (`preference_id`),
  KEY `FKq5oj1co3wu38ltb5g1xg9wel4` (`user_id`),
  CONSTRAINT `FKq5oj1co3wu38ltb5g1xg9wel4` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_preference`
--

LOCK TABLES `user_preference` WRITE;
/*!40000 ALTER TABLE `user_preference` DISABLE KEYS */;
INSERT INTO `user_preference` VALUES (4,'육류',1,1,3,3,2,5,1,7,'도수'),(86,'육류',3,5,2,5,2,4,2,12,'안주'),(87,'디저트',3,1,2,4,5,1,5,4,'맛'),(90,'탕/전골',3,2,4,2,1,4,2,13,'맛'),(91,'탕/전골',1,3,3,4,2,4,2,8,'맛'),(92,'탕/전골',3,4,3,3,1,4,2,6,'안주'),(94,'육류',2,3,4,4,3,5,2,14,'맛'),(95,'탕/전골',1,3,3,3,1,4,1,15,'맛'),(96,'탕/전골',4,2,3,4,2,3,3,16,'안주'),(97,'전/무침',2,3,4,4,4,4,2,17,'맛');
/*!40000 ALTER TABLE `user_preference` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-07 11:11:06
