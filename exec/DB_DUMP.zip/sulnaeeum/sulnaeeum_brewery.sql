-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: sulnaeeum
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `brewery`
--

DROP TABLE IF EXISTS `brewery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `brewery` (
  `brewery_id` bigint NOT NULL,
  `brewery_img` varchar(255) NOT NULL,
  `brewery_location` varchar(50) NOT NULL,
  `brewery_name` varchar(20) NOT NULL,
  `brewery_url` varchar(255) NOT NULL,
  `contact` varchar(12) NOT NULL,
  `map_id` bigint DEFAULT NULL,
  PRIMARY KEY (`brewery_id`),
  KEY `FKbr6bww6itn6fgbgagmwk7wv0s` (`map_id`),
  CONSTRAINT `FKbr6bww6itn6fgbgagmwk7wv0s` FOREIGN KEY (`map_id`) REFERENCES `map` (`map_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `brewery`
--

LOCK TABLES `brewery` WRITE;
/*!40000 ALTER TABLE `brewery` DISABLE KEYS */;
INSERT INTO `brewery` VALUES (1,'https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/brewery/1.jpg','경북 영천시 고경면 고도리 494-3','고도리 와이너리','http://고도리와인.com','054-335-3174',5),(2,'https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/brewery/2.jpg','강원도 횡성군 둔내면 현천리 120','국순당','http://www.ksdb.co.kr','033-340-4300',2),(3,'https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/brewery/3.jpg','경기도 안산시 단원구 뻐꾹산길 107','그린영농조합','http://www.grandcoteau.co.kr','032-886-9873',1),(4,'https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/brewery/4.jpg','부산 금정구 산성로 453','금정산성 토산주','http://www.sanmak.kr/','051-517-6552',5),(5,'https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/brewery/5.jpg','전남 진도군 군내면 둔전리 98','대대로영농조합법인','http://www.e-hongju.co.kr','061-542-3399',4),(6,'https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/brewery/6.jpg','충청북도 영동군 매곡면 옥전리 825-1','도란원','http://xn--hg3b13gpoq4muubvz4a.kr/','043-743-2109',3),(7,'https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/brewery/7.jpg','경상남도 함양군 지곡면 지곡창촌길 3','명가원','http://www.mgwkorea.com','055-963-8992',5),(8,'https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/brewery/8.jpg','경북 안동시 풍산읍 산업단지6길 6','명인안동소주','http://www.adsoju.com','054-856-6903',5),(9,'https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/brewery/9.jpg','경상북도 문경시 동로면 노은리 192번지','문경주조','https://mgomijasul.modoo.at/','054-552-8285',5),(10,'https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/brewery/10.jpg','경기도 평택시 포승읍 충열길 37','밝은세상영농조합','https://www.instagram.com/tigercalyx/','031-683-0981',1),(11,'https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/brewery/11.jpg','경기도 포천시 화현면 화현리 512','배상면주가','https://www.soolsool.co.kr/','031-531-9300',1),(12,'https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/brewery/12.jpg','경기도 화성시 정남면 서봉로 835','배혜정도가','http://www.baedoga.co.kr/','031-354-9376',1),(13,'https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/brewery/13.jpg','경기 파주시 적성면 객현리 67-1','산머루농원','http://www.sanmeoru.com','031-958-4558',1),(14,'https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/brewery/14.jpg','경상북도 김천시 증산면 금곡리 226-1번지','수도산와이너리','https://smartstore.naver.com/sdsmeru','054-439-1518',5),(16,'https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/brewery/16.jpg','충남 당진시 신평면 신평로 813','신평양조장','http://www.koreansul.co.kr','041-362-6080',3),(17,'https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/brewery/17.jpg','충남 예산군 고덕면 대몽로 107-25','예산사과와인','http://www.chusawine.com','041-337-9584',3),(18,'https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/brewery/18.jpg','강원도 홍천군 내촌면 물걸리 508-2','예술주조','http://www.ye-sul.co.kr','033-435-1120',2),(19,'https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/brewery/19.jpg','경북 문경시 문경읍 새재로 609','오미나라','http://www.omynara.com/','054-572-0601',5),(20,'https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/brewery/20.jpg','경상북도 울진군 근남면 노음2길 4','울진술도가','https://map.naver.com/v5/search/%EC%9A%B8%EC%A7%84%EC%88%A0%EB%8F%84%EA%B0%80/place/38692387?entry=plt&c=15,0,0,0,dh&isCorrectAnswer=true','054-782-1855',5),(21,'https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/brewery/21.jpg','충청북도 옥천군 이원면 묘목로 113','이원양조장','http://iwonwine.com/new/index.php','043-732-2177',3),(22,'https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/brewery/22.jpg','제주도 서귀포시 표선면 중산간동로 4726','제주고소리술익는집','http://jejugosorisul.com/','064-787-5046',6),(23,'https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/brewery/23.png','제주 제주시 애월읍 애언로 283','제주샘주','http://www.jejusaemju.co.kr','064-799-4225',6),(24,'https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/brewery/24.jpg','충북 청주시 청원구 사천로 18길 5-2','조은술 세종','http://www.joeunsulsj.co.kr','043-218-7689',3),(25,'https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/brewery/25.jpg','경기 평택시 오성면 숙성뜰길 108','좋은술','https://jsul.modoo.at/','031-681-8929',1),(26,'https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/brewery/26.jpg','전북 남원시 운봉읍 서천리 622번지','지리산 운봉주조','http://www.herbsul.com/','063-634-0009',4),(27,'https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/brewery/27.jpg','전라남도 장성군 장섭읍 남양촌길 19','청산녹수','https://smartstore.naver.com/bluegreenk?NaPm=ct%3Dlg3g4pem%7Cci%3Dcheckout%7Ctr%3Dds%7Ctrx%3D%7Chk%3D94bbca9c38fb16b5708a2d27407ee28df434552f','061-393-4141',4),(28,'https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/brewery/28.jpg','전남 담양군 용면 추령로 29','추성고을','http://www.chusungju.co.kr','061-383-3011',4),(29,'https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/brewery/29.jpg','전북 정읍시 태인면 태흥리 392-1','태인합동주조장','http://www.태인양조장.com/','063-534-4018',4),(30,'https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/brewery/30.jpg','충청북도 청주시 청원구 내수읍 풍정1길 8-2','화양','http://hwayang.co/','043-214-9424',3),(31,'https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/brewery/31.jpg','울산광역시 울주군 상북면 향산동길 50','복순도가','https://boksoon.com/shopinfo/space.html','1577-6746',1);
/*!40000 ALTER TABLE `brewery` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-07 11:10:30
