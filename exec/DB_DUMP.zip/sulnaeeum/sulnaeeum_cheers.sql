-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: sulnaeeum
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cheers`
--

DROP TABLE IF EXISTS `cheers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cheers` (
  `cheers_id` bigint NOT NULL AUTO_INCREMENT,
  `cheers_content` varchar(255) NOT NULL,
  `cheers_name` varchar(255) NOT NULL,
  PRIMARY KEY (`cheers_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cheers`
--

LOCK TABLES `cheers` WRITE;
/*!40000 ALTER TABLE `cheers` DISABLE KEYS */;
INSERT INTO `cheers` VALUES (1,'청춘은 바로 지금!','청바지'),(2,'무척이나 화려했던 과거를 위하여','무화과'),(3,'오늘은 바래다 줄께 마시자','오바마'),(4,'단순하고 무식해도 무지 행복하게 살자','단무지'),(5,'소중한 나눔의 무한 행복을 위하여','소나무'),(6,'우리는 하늘 아래 하나다','우하하'),(7,'그래, 내일 또 도전하자','그래도'),(8,'기분좋게, 숙취없게, 사이좋게','기숙사'),(9,'누가 나의편? 언제나 니편!','누나언니'),(10,'뚝심있게, 배짱있게, 기운차게','뚝배기'),(11,'나쁜 일 땡, 좋은 일 큐!','땡큐'),(12,'마시고 취하는게 제일이다','마취제'),(13,'보다 나은 성공을 위하여','보나성'),(14,'아름다운 우리의 성공을 위하여','아우성'),(15,'야심차고 생생하고 화끈하게','야생화'),(16,'오래도록 징그럽게 어울리자','오징어'),(17,'우아하고 거룩하고 지성있게','우거지'),(18,'적당한 반주는 하나님도 장려한다','적반하장'),(19,'희망찬, 활기찬, 가득찬','찬찬찬'),(20,'유쾌, 상쾌, 통쾌','쾌쾌쾌'),(21,'흥해도 청춘, 망해도 청춘','흥청망청'),(22,'새롭게 신나게 발랄하게','새신발'),(23,'사랑과 우정, 이 잔에 담아, 다같이 원샷','사이다');
/*!40000 ALTER TABLE `cheers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-07 11:11:12
