-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: sulnaeeum
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ranking`
--

DROP TABLE IF EXISTS `ranking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ranking` (
  `ranking_id` bigint NOT NULL AUTO_INCREMENT,
  `female` bigint DEFAULT NULL,
  `fifties` bigint DEFAULT NULL,
  `forties` bigint DEFAULT NULL,
  `male` bigint DEFAULT NULL,
  `sixties` bigint DEFAULT NULL,
  `thirties` bigint DEFAULT NULL,
  `twenties` bigint DEFAULT NULL,
  `total` bigint DEFAULT NULL,
  PRIMARY KEY (`ranking_id`),
  KEY `FKsb26v4c4g0siud4eu5ncupebc` (`female`),
  KEY `FKoubf86cn6l55cpcb3g1npw46f` (`fifties`),
  KEY `FKdehaffuqn9dhqonx1xk0j7w5x` (`forties`),
  KEY `FK1xnfem1tulp5e9ui575ks7lki` (`male`),
  KEY `FK8pw419fjqyosflo324wbcvjtb` (`sixties`),
  KEY `FK8k8n9rcn62s0p85r7isgiye8i` (`thirties`),
  KEY `FKsuwt6q4yk9ofp7q9cfkujru6l` (`twenties`),
  KEY `FK58afgtoj0owf7vg4f3gtwopfe` (`total`),
  CONSTRAINT `FK1xnfem1tulp5e9ui575ks7lki` FOREIGN KEY (`male`) REFERENCES `drink` (`drink_id`),
  CONSTRAINT `FK58afgtoj0owf7vg4f3gtwopfe` FOREIGN KEY (`total`) REFERENCES `drink` (`drink_id`),
  CONSTRAINT `FK8k8n9rcn62s0p85r7isgiye8i` FOREIGN KEY (`thirties`) REFERENCES `drink` (`drink_id`),
  CONSTRAINT `FK8pw419fjqyosflo324wbcvjtb` FOREIGN KEY (`sixties`) REFERENCES `drink` (`drink_id`),
  CONSTRAINT `FKdehaffuqn9dhqonx1xk0j7w5x` FOREIGN KEY (`forties`) REFERENCES `drink` (`drink_id`),
  CONSTRAINT `FKoubf86cn6l55cpcb3g1npw46f` FOREIGN KEY (`fifties`) REFERENCES `drink` (`drink_id`),
  CONSTRAINT `FKsb26v4c4g0siud4eu5ncupebc` FOREIGN KEY (`female`) REFERENCES `drink` (`drink_id`),
  CONSTRAINT `FKsuwt6q4yk9ofp7q9cfkujru6l` FOREIGN KEY (`twenties`) REFERENCES `drink` (`drink_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ranking`
--

LOCK TABLES `ranking` WRITE;
/*!40000 ALTER TABLE `ranking` DISABLE KEYS */;
INSERT INTO `ranking` VALUES (1,447,473,156,451,473,372,451,425),(2,417,469,153,455,469,383,455,441),(3,416,483,209,452,461,374,452,390),(4,451,479,167,459,447,386,459,432),(5,455,480,180,461,459,390,461,444),(6,461,461,197,469,479,417,469,451),(7,383,476,157,447,480,416,447,455),(8,428,509,158,453,451,324,453,383),(9,386,459,176,473,455,373,473,417),(10,390,488,183,417,462,378,417,430);
/*!40000 ALTER TABLE `ranking` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-07 11:10:17
