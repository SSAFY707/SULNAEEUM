-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: sulnaeeum
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `my_drink`
--

DROP TABLE IF EXISTS `my_drink`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `my_drink` (
  `my_drink_id` bigint NOT NULL,
  `drink_id` bigint DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`my_drink_id`),
  KEY `FKc1x7hwnt17n0v7vb2auwf9vr2` (`drink_id`),
  KEY `FKm8op7evmijnmhu8n2qk556h2p` (`user_id`),
  CONSTRAINT `FKc1x7hwnt17n0v7vb2auwf9vr2` FOREIGN KEY (`drink_id`) REFERENCES `drink` (`drink_id`),
  CONSTRAINT `FKm8op7evmijnmhu8n2qk556h2p` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `my_drink`
--

LOCK TABLES `my_drink` WRITE;
/*!40000 ALTER TABLE `my_drink` DISABLE KEYS */;
INSERT INTO `my_drink` VALUES (2,1,6),(3,142,6),(4,270,6),(5,505,6),(6,493,6),(7,533,6),(8,583,6),(9,449,6),(10,510,6),(11,209,6),(12,267,6),(13,3,12),(610,5,9),(614,339,12),(803,203,12),(832,10,4),(834,10,7),(859,10,6),(861,196,6),(863,432,6),(867,471,6),(879,8,9),(886,634,9),(889,127,9),(894,636,9),(920,224,6),(927,194,6),(929,224,7),(933,224,8),(938,224,4),(995,557,12),(1003,425,7),(1012,425,4),(1014,441,4),(1016,390,4),(1018,447,7),(1020,417,7),(1023,390,7),(1025,441,7);
/*!40000 ALTER TABLE `my_drink` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-07 11:10:35
