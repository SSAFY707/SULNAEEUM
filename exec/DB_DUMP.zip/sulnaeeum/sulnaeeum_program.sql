-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: sulnaeeum
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `program`
--

DROP TABLE IF EXISTS `program`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `program` (
  `program_id` bigint NOT NULL,
  `always_visit` bit(1) NOT NULL,
  `content` varchar(255) NOT NULL,
  `program_img` varchar(255) NOT NULL,
  `program_location` varchar(30) NOT NULL,
  `program_name` varchar(20) NOT NULL,
  `program_url` varchar(255) NOT NULL,
  `reserve_visit` bit(1) NOT NULL,
  `map_id` bigint DEFAULT NULL,
  PRIMARY KEY (`program_id`),
  KEY `FK5n0bd5v2et1iqbppcl7s9ujsc` (`map_id`),
  CONSTRAINT `FK5n0bd5v2et1iqbppcl7s9ujsc` FOREIGN KEY (`map_id`) REFERENCES `map` (`map_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `program`
--

LOCK TABLES `program` WRITE;
/*!40000 ALTER TABLE `program` DISABLE KEYS */;
INSERT INTO `program` VALUES (1,_binary '','수확한 포도를 와인만들기 체험장으로 가지고 와서 농장주 소믈리에와 함께 와인만들기 체험을 합니다. 만든 와인은 통을 깨끗이 씻어 댁으로 가져가실 수 있으십니다.','https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/program/1.jpg','고도리와이너리','와인 만들기 체험','http://고도리와인.com',_binary '',5),(2,_binary '\0','국순당은 우리 술 문화 체험공간인 주향로를 중심으로 양조장 견학, 우리술 빚기 체험 등을 운영하고 있다. 홈페이지를 통해 주향로 견학을 신청할 수 있으며, 국립횡성숲체원과 협력해 산림치유 프로그램도 비정기적으로 운영하고 있다. 국순당은 시기에 따라 다양한 우리술 체험 프로그램을 운영해 우리 술의 역사를 바로 알고 올바른 전통 술 문화를 체험할 수 있도록 제시하고 있다.','https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/program/2.jpg','우리술아름터','우리술 빚기 체험','http://www.ksdb.co.kr',_binary '',2),(3,_binary '','와인의 역사,매너,한국의 음식문화와 와인 등 강의/와인 시음(3종, 4종)','https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/program/3.jpg','그랑꼬또 와이너리','양조장 투어','http://www.grandcoteau.co.kr',_binary '',1),(4,_binary '','우리 전통 족타식으로 건강한 누룩을 만듭니다. 전통 누룩은 발효과정에서 당화 효소와 효모가 모두 들어있습니다. 가운데가 얇고 테두리는 두툼해 수분이 더 모여있어 자체 발효가 됩니다.','https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/program/4.jpg','금정산성막걸리','누룩 딛기 체험','http://www.sanmak.kr/',_binary '',5),(5,_binary '','진도에는 \'홍주\'라는 역사 깊은 술이 있습니다. 흔히 색이 붉어 홍주라하고, 지초를 통과한다 하여 지초주라고도 부릅니다. 진도홍주는 누구나 체험과 시음 행사를 즐길 수 있습니다.','https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/program/5.jpg','대대로영농조합법인','홍주 시음 체험','http://www.e-hongju.co.kr',_binary '',4),(6,_binary '','도란원은 와인 강의, 시음, 9월~10월 포도 수확철에 맞춰 와인만들기, 와인 족욕 등의 체험을 진행하고 있다. 체험은 도란원 홈페이지에서 신청이 가능하다. 방문 인원에 따라 체험이 제한될 수 있기 때문에 여러 명이 방문할수록 다양한 체험을 할 수 있다.','https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/program/6.jpg','샤토미소 도란원','와인 체험','http://xn--hg3b13gpoq4muubvz4a.kr/',_binary '',3),(7,_binary '','솔송주와 담솔 시음,솔송주 문화관 내부 관람 가능','https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/program/7.jpg','솔송주 문화관','시음 및 솔송주 문화관 관람','http://www.mgwkorea.com',_binary '',4),(8,_binary '','막걸리(단양주) 빚기 (빚은 술은 직접 가져가서 발효 시키기)','https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/program/8.jpg','명인 안동소주 양조장','전통주 빚기','http://www.adsoju.com',_binary '',4),(9,_binary '','직접 막걸리 빚어보고 짜기','https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/program/9.jpg','문경주조양조장','막걸리 빚기, 찌기','https://mgomijasul.modoo.at/',_binary '\0',4),(10,_binary '\0','양조장의 증류주로 만들어보는 다양한 플레이보의 담금주 만들기','https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/program/10.jpg','밝은세상영농조합','담금주 체험','https://www.instagram.com/tigercalyx/',_binary '',1),(11,_binary '','제철 과실로 빚는 술 빚기 체험','https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/program/11.jpg','배상면주가','과실주 빚기','https://www.soolsool.co.kr/',_binary '\0',1),(12,_binary '\0','일반인 대상 탁주 제조 및 증류주 제조 공장 동시 견학 프로그램','https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/program/12.jpg','배혜정도가','견학','http://www.baedoga.co.kr/',_binary '',1),(13,_binary '\0','생산되어 있는 머루와인을 본인의 병에 담아가기','https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/program/13.jpg','산머루 농원','나만의 와인','http://www.sanmeoru.com',_binary '',1),(14,_binary '','크라테와인+ 과일과 향신료를 넣고 끓여 마시는 유럽식 쌍화차 만들기','https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/program/14.jpg','수도산 와이너리 체험장','뱅쇼만들기','https://smartstore.naver.com/sdsmeru',_binary '',4),(15,_binary '','전통주강의, 간단체험, 제조장 견학, 시음','https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/program/15.jpg','술샘','체험 및 견학','http://www.sulseam.com',_binary '\0',1),(16,_binary '','전통주 강의, 막걸리 빚기, 제품 시음 (본인이 빚은 막걸리 가져가기)','https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/program/16.jpg','신평 양조장 교육장','막걸리(단양주)빚기','http://www.koreansul.co.kr',_binary '\0',3),(17,_binary '','예산 황토땅에서 자란 맛있는 사과를 직접 따기','https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/program/17.jpg','사과농장','사과따기','http://www.chusawine.com',_binary '\0',3),(19,_binary '','오미로제 프리미어 와인 또는 문경바람을 병입, 코킹 및 캡실링후, 기념문구가 담긴 라벨을 부착하여 세상에 단 하나 뿐인 나만의 기념주 만들기 체험 프로그램 입니다.','https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/program/19.jpg','오미자농원','나만의 기념주 만들기 체험','http://www.omynara.com/',_binary '\0',5),(20,_binary '','90년 전통의 한국술 장인의 소개로 양조장을 견학하고 신선한 원주를 직접 거르고 병에 담아가는 프로그램으로 자신만의 라벨이 붙어있는 “나만의 원주”를 만나실 수 있습니다.','https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/program/20.jpg','이원양조장','나만의 원주 만들기','http://iwonwine.com/new/index.php',_binary '',3),(21,_binary '','간단한 제주전통음식 4종과 전통주 2종 시음','https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/program/21.jpg','제주술익는집','제주 전통식 시음체험','http://jejugosorisul.com/',_binary '',6),(22,_binary '','오메기술과 고소리술을 베이스로 칵테일 제조 시음 체험','https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/program/22.jpg','제주샘酒 양조장','칵테일 만들기 체험','http://www.jejusaemju.co.kr',_binary '\0',6),(23,_binary '\0','막걸리, 약주, 증류식소주, 과실주 등 비교시음 및 양조장 견학','https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/program/23.jpg','조은술 세종 회의실 및 양조장','시음 및 양조장 견학','http://www.joeunsulsj.co.kr',_binary '',3),(24,_binary '','3~4명이 한 조를 이루어 술을 빚습니다. 빚은 술은 4리터 투명 페트병에 담아 집으로 가져가서 발효시키면 됩니다. 발효 후 채주하면 3~4병이 나옵니다. 막걸리로 바로 잡수셔도 되고, 냉장고에 넣었다가 맑은 술로 잡수셔도 됩니다. 결혼식이나 부모님 칠순 잔치 등에 축하주 또는 답례품으로 활용할 수도 있습니다.','https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/program/24.jpg','좋은술','찾아가는 양조장 술빚기','https://jsul.modoo.at/',_binary '',1),(25,_binary '','막걸리 빚기 체험','https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/program/25.jpg','지리산 운봉주조 전통주 체험관','막걸리 빚기','https://herbsul.modoo.at/',_binary '',4),(26,_binary '\0','명인주 유래 및 소개 / 대통 계란 만들기 / 개인라벨용 사진촬영 / 대통술 만들기 / 전통소줏고리 체험 / 시음 및 라벨부착(시음 시 부침, 계절안주 제공)','https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/program/26.jpg','추성고을 체험학습관','추월산','http://www.chusungju.co.kr',_binary '',4),(27,_binary '\0','죽력체험,누룩체험,술만들기체험,증류주 내리기','https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/program/27.jpg','태인양조장','죽력체험','http://www.태인양조장.com/',_binary '',4),(28,_binary '','증류주 칵테일 만들기','https://sulnaeeum.s3.ap-northeast-2.amazonaws.com/program/28.jpg','화양 제 2공장 체험장','칵테일 만들기','http://hwayang.co/',_binary '',3);
/*!40000 ALTER TABLE `program` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-07 11:10:53
