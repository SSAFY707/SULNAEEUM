-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: sulnaeeum
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `brewery_drink_type`
--

DROP TABLE IF EXISTS `brewery_drink_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `brewery_drink_type` (
  `brewery_drink_type_id` bigint NOT NULL,
  `brewery_id` bigint DEFAULT NULL,
  `drink_type_id` bigint DEFAULT NULL,
  PRIMARY KEY (`brewery_drink_type_id`),
  KEY `FKmbaivpu4nvhivv71k4829sm84` (`brewery_id`),
  KEY `FK2rr4lqhy5bi8i0v9dmw9t7fbf` (`drink_type_id`),
  CONSTRAINT `FK2rr4lqhy5bi8i0v9dmw9t7fbf` FOREIGN KEY (`drink_type_id`) REFERENCES `drink_type` (`drink_type_id`),
  CONSTRAINT `FKmbaivpu4nvhivv71k4829sm84` FOREIGN KEY (`brewery_id`) REFERENCES `brewery` (`brewery_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `brewery_drink_type`
--

LOCK TABLES `brewery_drink_type` WRITE;
/*!40000 ALTER TABLE `brewery_drink_type` DISABLE KEYS */;
INSERT INTO `brewery_drink_type` VALUES (1,1,3),(2,2,1),(3,2,4),(4,3,3),(5,4,1),(6,5,4),(7,6,3),(8,7,2),(9,7,4),(10,8,4),(11,9,1),(12,9,2),(13,10,1),(14,10,4),(15,11,1),(16,11,2),(17,11,4),(18,12,1),(19,12,4),(20,13,3),(21,14,3),(25,16,1),(26,16,2),(27,17,3),(28,17,4),(29,18,1),(30,18,2),(31,19,3),(32,19,4),(33,20,1),(34,21,1),(35,22,4),(36,23,2),(37,23,4),(38,24,1),(39,24,4),(40,24,5),(41,25,1),(42,25,2),(43,25,4),(44,26,1),(45,27,1),(46,28,2),(47,28,4),(48,29,1),(49,29,4),(50,30,1),(51,30,2),(52,30,4),(53,31,1);
/*!40000 ALTER TABLE `brewery_drink_type` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-07 11:10:25
