-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: sulnaeeum
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_id` bigint NOT NULL AUTO_INCREMENT,
  `activated` tinyint DEFAULT NULL,
  `age` varchar(255) DEFAULT NULL,
  `finish` tinyint NOT NULL,
  `img` varchar(255) NOT NULL,
  `kakao_id` varchar(255) NOT NULL,
  `nickname` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `ranking` int NOT NULL,
  `token` varchar(255) DEFAULT NULL,
  `sex` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `UK_4tp32nb01jmfcirpipti37lfs` (`kakao_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (4,1,'20s',1,'http://k.kakaocdn.net/dn/ccm9k3/btr32vaK5pj/lCrukBd6M1gZtN05DbBHYk/img_640x640.jpg','2706446545','박미희','$2a$10$k8vuP0rU2zucckkWRL1Lmu6tQ2wEdZC9/iL7fmqMo1uZ2rZfJppoe',0,'eyJhbGciOiJIUzUxMiJ9.eyJleHAiOjE2OTUzNDcxMTJ9.4qtWsWVqcdh2MIWyZzqGGEqbPnlWj52v6NcE6k5JvTPyrw5Sh-dKOB-0IWq_A-nN3cayrApRmuTN1kGRe2IH9g','여성'),(6,1,'20s',1,'http://k.kakaocdn.net/dn/bVmGzp/btrzUizU0Gr/cDWAvuQAzziGItZZREVZe1/img_640x640.jpg','2727041900','김나현','$2a$10$3iw0LriQXCgOsJEnbpDBbu2Hd/EZTF6xdOb87o972oCj7ckdvO3/a',0,NULL,'여성'),(7,1,'20s',1,'http://k.kakaocdn.net/dn/dpk9l1/btqmGhA2lKL/Oz0wDuJn1YV2DIn92f6DVK/img_640x640.jpg','2706872522','김원규','$2a$10$D2GWTQrjiu8DAEzsQmMA6uIzRMEwW6yemhCi6msyGB9x54OTCft5K',0,'eyJhbGciOiJIUzUxMiJ9.eyJleHAiOjE2OTUzMzgyMzV9.HQYLgKNrqyM_hGE6SCej94EI0NxFevN0OfiNZQupKG0QcBAlEl81r4bxY1HwN7t9tEwg_5SEjQrSoUYHxHC2wg','남성'),(8,1,NULL,1,'http://k.kakaocdn.net/dn/dpk9l1/btqmGhA2lKL/Oz0wDuJn1YV2DIn92f6DVK/img_640x640.jpg','2727171257','오하늘','$2a$10$eUbCfH/CcUAdMww6jX5NGup.y2eV4FRNFcp3rg0m/B6bNi8Au3jMC',0,'eyJhbGciOiJIUzUxMiJ9.eyJleHAiOjE2OTUyODQ1NTR9.y4ikzbJuG9yqXvVgODHvAF4YP5tpJDoLpSWZiuP7HyY4I_NrFMQnyAQ8J8KZ955Zl3JMNoqKwBjuc7c9v6Rzpg',NULL),(9,1,'20s',1,'http://k.kakaocdn.net/dn/cMUQdh/btr5QoWuQjb/g28zrtCmvxMmkcn1iiso91/img_640x640.jpg','2706849396','김설희','$2a$10$qSE9Bqhf68Wxj8xN/wyUM..vx.XJ/.51GJK9y073JGgK/RAlBTBb6',0,'eyJhbGciOiJIUzUxMiJ9.eyJleHAiOjE2OTUzNDcwODJ9.sId2xKximAb6k_emxc3bXEe3jHTZYK-oC6ZBicQQ2ZPGR4JG5Euc0lQYPIkYQcwrwQNKPNs0hx8GdEgK1Za3VQ','여성'),(10,1,NULL,1,'http://k.kakaocdn.net/dn/bJmYd6/btrXqrzNDzB/krb6y35vN2idBOnalR1KgK/img_640x640.jpg','2731946115','정연','$2a$10$2ho211Z.8KpoZcs/gAKzjOWDOZP77gQQT22P7rjS14Xpn4MhVM7s2',0,'eyJhbGciOiJIUzUxMiJ9.eyJleHAiOjE2OTQ5NDEzNzF9.GmO0dggizA7yY3IdibQTGIHwq7EAtWpVmLKwpWggfJXGoPskySP_rbEedBHB02uacXt96mneW2YOscuAZTzS7g',NULL),(12,1,'40s',1,'http://k.kakaocdn.net/dn/mO1sR/btrXtTijdTT/WGzTWTj5KMwePjYX1molmK/img_640x640.jpg','2720236385','이성훈','$2a$10$pzuVlpH4NhuXgKFPZoSHW.H8JhM0Zv1ZMWjAv0/RyyVxyu/1XhX.m',0,'eyJhbGciOiJIUzUxMiJ9.eyJleHAiOjE2OTUzMDY3MTZ9.SL8hY2D7tCEu8N5e5ir_3D688efuoquGo-MjUSjOu8eSS81sJS-CO9gSaA07Fu_f20OHfx1Kr_x-fSBe8xpRQw','남성'),(13,1,NULL,1,'http://k.kakaocdn.net/dn/rIRT4/btrQpyeeUTm/l8mMPXjBxoy1mSbPfUmVu0/img_640x640.jpg','2736230055','고성현','$2a$10$/ReWIaMELxAIt2KqV/zCluil2.hco62HzLw2b4JSKZuPRat6KdXWi',0,'eyJhbGciOiJIUzUxMiJ9.eyJleHAiOjE2OTUxODYwNzN9.QOAP00_PQ6kwUotZdBxP8VzbkvM3xr_nFW48B1jP8w11JEVuBeXq0DyDGprd488PSWWfyXo54A240su1670xYw',NULL),(14,1,'30s',1,'http://k.kakaocdn.net/dn/dpk9l1/btqmGhA2lKL/Oz0wDuJn1YV2DIn92f6DVK/img_640x640.jpg','2738230875','상현','$2a$10$5HT8vnwEWzc2Kvv8rjCufuacDn2wj3Bv.PSRHNAA4J8qvpUBrPJV6',0,'eyJhbGciOiJIUzUxMiJ9.eyJleHAiOjE2OTUyOTkzODF9.1tWOtW5sNyS7wTVpUk7a1uH17X-PLDrfXTckHZkN_O75BhS7bM52SWa2sxuSXQgn2WfW88lrTOhRKfZLlrs6MA','남성'),(15,1,'20s',1,'http://k.kakaocdn.net/dn/bwBy9M/btr6eUMImdv/I8xAr31f8LfJbhCM58hCSk/img_640x640.jpg','2738260456','이윤주','$2a$10$bvWgXQIk/ozNQS.3WEd/mucygBZpbKgx43mvJmNMrOa2yJyPU4KTu',0,'eyJhbGciOiJIUzUxMiJ9.eyJleHAiOjE2OTUzMDA2MTV9.QcICE5kAxHz9D-x1GrTWQkJyQvd7T0AfANZ2nYGPm7qIigcZl7ZcRMBBonsQS-qNeY0zpBZ3TevRMLueSS4GEQ','여성'),(16,1,'20s',1,'http://k.kakaocdn.net/dn/X4GZk/btr1fOw2ErZ/fIV7mLsPVB6S00rTP9D6W0/img_640x640.jpg','2738364703','이예진','$2a$10$nHzuDfKO6VK98xXCQiigUO.5gY7Tmx2WfqO0LN/TpQiKlUxX/Da8q',0,NULL,'여성'),(17,1,'20s',1,'http://k.kakaocdn.net/dn/EYRjC/btr7e0UqWrE/R3IZKCPMcFmDpue61wrqH0/img_640x640.jpg','2738380960','박수민','$2a$10$2rgNCIY8DsUgdccv3/UJAe8TjBrZR.GxTSn1LyDpJ7i6A97r1.WKG',0,'eyJhbGciOiJIUzUxMiJ9.eyJleHAiOjE2OTUzMDYwOTF9.GgE98AClIm61rRnBtosbXHOyng9qyaOoA-e5hyduCpOGoCFQDBkp1ucOvkjXZNCfJFroBWb3htsqSM2tmmmMBQ','여성');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-07 11:10:22
