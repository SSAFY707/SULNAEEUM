-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: sulnaeeum
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `jumak`
--

DROP TABLE IF EXISTS `jumak`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jumak` (
  `jumak_id` bigint NOT NULL,
  `jumak_location` varchar(255) DEFAULT NULL,
  `jumak_name` varchar(10) DEFAULT NULL,
  `jumak_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`jumak_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jumak`
--

LOCK TABLES `jumak` WRITE;
/*!40000 ALTER TABLE `jumak` DISABLE KEYS */;
INSERT INTO `jumak` VALUES (1,'서울 서초구 언남길 64 덕성빌딩 1층','페페','https://place.map.kakao.com/830765565'),(2,'서울 강남구 역삼로14길 10 1층 거나하게','거나하게','https://place.map.kakao.com/194050352'),(3,'서울 광진구 뚝섬로23길 60 1층','고이장','https://place.map.kakao.com/1962674185'),(4,'서울 광진구 면목로7길 13 1층','몽우','https://place.map.kakao.com/1174834534'),(5,'서울 서초구 강남대로34길 38 2층 진여사댁','진여사댁','https://place.map.kakao.com/1539389679'),(6,'서울 마포구 동교로46길 24-2 2층 이끔','이:끔','https://place.map.kakao.com/1013059049'),(7,'서울 용산구 신흥로 47','산솔','https://place.map.kakao.com/393840934'),(8,'서울 관악구 봉천로 461-1 1층','막걸리전당','https://place.map.kakao.com/893190505'),(9,'서울 성북구 보문로34길 87 1층','한식술집 돌','https://place.map.kakao.com/270107262'),(10,'서울 종로구 종로32길 7','박가네 빈대떡','https://place.map.kakao.com/12543498'),(11,'서울 동작구 동작대로27가길 37 2층','종부네','https://place.map.kakao.com/117392413'),(12,'서울 노원구 한글비석로20길 62 송림빌딩 101호','화실','https://place.map.kakao.com/581712804'),(13,'서울 광진구 면목로31 (1층)','미주류','https://place.map.kakao.com/1966216348'),(14,'서울특별시 성동구 연무장길 41-22 지하 1층','청주한씨','https://place.map.kakao.com/1278787747'),(15,'서울 종로구 서순라길 101(1층)','우리술집다람쥐','https://place.map.kakao.com/726216640'),(16,'서울특별시 용산구 우사단로10길 135 1층 오보강','오보강','https://place.map.kakao.com/993397513'),(17,'서울 마포구 동교로46길 25 202호','서우막걸리','https://place.map.kakao.com/2059963997'),(18,' 서울 광진구 천호대로109길 7 1층','도르리','https://place.map.kakao.com/1689061003'),(19,'서울 관악구 신림로 305','솟대막걸리 양조장','https://place.map.kakao.com/7960862'),(20,'서울 마포구 마포대로4가길 41','삼씨오화','https://place.map.kakao.com/1989078189'),(21,'서울 마포구 동교로 262-3 jumak_name1층','윤달','https://place.map.kakao.com/692041493'),(22,'서울 성동구 고산자로14길 26','주052','https://place.map.kakao.com/2007025726'),(23,' 서울 성북구 고려대로24가길 13-2 1F','늘,안암','https://place.map.kakao.com/354752131'),(24,' 서울 강남구 압구정로48길 39','백곰막걸리','https://place.map.kakao.com/1151874015'),(25,'서울 강남구 논현로163길 13-4 지하1층','작정','https://place.map.kakao.com/511693888'),(26,'서울 종로구 자하문로33길 10 1층','독도16','https://place.map.kakao.com/1045968517'),(27,'서울 동작구 사당로30길 28 1층','낯선한식븟다','https://place.map.kakao.com/582047071'),(28,'서울 종로구 보문로1길 7-4','학술적연구소','https://place.map.kakao.com/1113230177'),(29,'서울 성동구 금호산2길 18 1층','금남정','https://place.map.kakao.com/136507271'),(30,'서울특별시 서대문구 연희맛로 36','요릿집','https://place.map.kakao.com/2033023940'),(31,'서울특별시 마포구 동교로38길 7','연남고집','https://place.map.kakao.com/1256711971'),(32,' 서울 성북구 동소문로2길 25','성북동 막걸리','https://place.map.kakao.com/12333162'),(33,' 서울 마포구 서강로9길 60','산울림1992','https://place.map.kakao.com/2036183426'),(34,'서울 마포구 양화로6길 77','술개구리','https://place.map.kakao.com/26603664'),(35,'서울 마포구 토정로 263','이박사 신동막걸리','https://place.map.kakao.com/14536745'),(36,'서울 마포구 양화진길 5','가제트 술집','https://place.map.kakao.com/13323566'),(37,'서울 동작구 동작대로25길 41','막걸리학교','https://place.map.kakao.com/14586281'),(38,'서울 관악구 남부순환로272길 8','막걸리이야기','https://place.map.kakao.com/543688925'),(39,'서울 강북구 월계로7나길 30-3','주막','https://place.map.kakao.com/17664320'),(40,'서울 도봉구 도봉로 181길 70','팔뚝집','https://place.map.kakao.com/1532546627'),(41,'서울 서초구 잠원동 69-2 반포쇼핑타운 4동 지하','담은','https://place.map.kakao.com/18629885'),(42,' 서울시 광진구 화양동 47-1번지 2층','술이송송','https://place.map.kakao.com/27339720'),(43,'서울 강남구 논현로95길 14','작','https://place.map.kakao.com/16301806'),(44,' 서울 강남구 선릉로157길 26','마법갈비 요술꼬치','https://place.map.kakao.com/1586875098'),(45,'서울 강남구 언주로152길 13','청담만옥','https://place.map.kakao.com/2051548735'),(46,'서울 강남구 언주로168길 22','묵전','https://place.map.kakao.com/14532428'),(47,'서울 강남구 도산대로51길 39 jumak_name1','막걸리는 살아있다','https://place.map.kakao.com/1752607024'),(48,'서울 강남구 선릉로111길 8','달빛보쌈','https://place.map.kakao.com/1017825251'),(49,'서울 강남구 봉은사로18길 88','대동집 강남점','https://place.map.kakao.com/1149253821'),(50,' 서울 용산구 신흥로 31','다모토리 히읗','https://place.map.kakao.com/11794306'),(51,'서울 용산구 이태원동 257-4','한국술집 안씨막걸리','https://place.map.kakao.com/1384545112'),(52,'서울 용산구 신흥로 81-1','해방촌 윤주당','https://place.map.kakao.com/901356055'),(53,'서울특별시 서대문구 연희맛로 4 다송빌딩 2층','이파리','https://place.map.kakao.com/577374445'),(54,'서울 서대문구 경기대로 43','물뛴다\n','https://place.map.kakao.com/17344160'),(55,'서울 종로구 윤보선길 26','산체스 막걸리','https://place.map.kakao.com/16041318'),(56,'서울 종로구 동숭2길 3-4','두두','https://place.map.kakao.com/18828141'),(57,'서울 종로구 돈화문로11다길 31','익선반주','https://place.map.kakao.com/1497027837'),(58,'서울 종로구 익선동 166-52','반기다','https://place.map.kakao.com/1092827830'),(560,'서울 동대문구 경동시장로 1 1층','요술식당','http://요술식당.kr'),(591,'서울 강남구 테헤란로 212 14층 1402호','알보칠리새우 식당','https://j8a707.p.ssafy.io');
/*!40000 ALTER TABLE `jumak` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-07 11:10:32
